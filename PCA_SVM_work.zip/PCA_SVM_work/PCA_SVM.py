#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Yacine Mehadji 
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.svm import SVC
import seaborn as sb
from sklearn.model_selection import train_test_split
from scipy.stats import pearsonr
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn import metrics

"""--------------------Practicing PCA on two examples----------------------"""

#data=np.matrix([[1,5,3,3],[4,4,3,5]])
# moyennedata=np.mean(data)
# print(data)
# plt.figure()
# plt.scatter(data[:,0],data[:,1])


#B=np.array([[1.268,4.732,3.5,2.5],[3,5,3.134,4.866]])
# moyenneB=np.mean(B)
#plt.figure()
#plt.scatter(B[:,0],B[:,1])
#print(B)

print('Using PCA into these examples, we have been able to reduce the data from 2 dim to 1 dim, to implement the six steps of PCA')

"""------------------Applying PCA to the flower dataset--------------------"""

data = pd.read_csv("flowerTrain.data", names=['sepal length','sepal width','petal length','petal width','species'])
x = data.iloc [:,0:4]
plt.figure()
plt.scatter(data.iloc [:,0], data.iloc [:,1], alpha=0.2, s=100*data.iloc [:,2], c=100*data.iloc [:,3])
plt.title('Scattered plot of the flower training dataset')

def PCA(x , reducedDim):
    mean = np.mean(x, axis= 0) #Compute the mean of all measures 
    print(mean)
    mean_data = x - mean       #Shift matrix by this mean
    print(mean_data, "\n")
    #plt.figure()
    #plt.scatter(mean_data.iloc [:,0], mean_data.iloc [:,1], alpha=0.2, s=100*data.iloc [:,2], c=100*data.iloc [:,3])
    #plt.title('Mean Data')

    cov = np.cov(mean_data.astype(float), rowvar=False) #Build the dataset covariance matrix 
    print("Covariance matrix ", cov.shape, "\n")
    print(cov)

    eig_vals, eig_vecs = np.linalg.eigh(cov) #Using Singular Value Decomposition, extract eigenvalues and normalized eigenvectors 
    idx = eig_vals.argsort()[::-1] #choose the p largest eigenvalues and reduce U to the corresponding p eigenvectors (columns)
    eig_vals = eig_vals[idx]
    eig_vecs = eig_vecs[:,idx]
    print("\nEigen vectors are :\n ", eig_vecs)
    print("\nEigen values are : ", eig_vals, "\n")

    
    Up = eig_vecs.T[:][:2].transpose()
    S = np.dot(Up.transpose(),mean_data.transpose()).transpose() #project each sample to reduce its dimensions 
    print("Principal Component Size", S.shape, "\n")
    principal_df = pd.DataFrame(S , columns = ['PC1','PC2'])
    principal_df = pd.concat([principal_df , data.loc[:,['species']]] , axis = 1)
    
    plt.figure()
    plt.scatter(principal_df['PC1'], principal_df['PC2'])
    sb.scatterplot(data = principal_df , x = 'PC1',y = 'PC2' , hue = 'species' , s = 60 , palette= 'icefire')
    plt.title('Principal component of the flower training dataset')

    #Correlation Coefficient
    coef_cor_data, pvalue_data = pearsonr(data.iloc[:,0], data.iloc[:,1])
    print('correlation coefficient of original dataset : ', coef_cor_data, pvalue_data)
    print('\nThere is a strong and statistically significant correlation between SEPAL LENGTH and SEPAL WIDTH')
    print('\nThe PCA makes it possible to decorrelate these variables')
    
    PC1 = S[:,0] #The first principal component 
    PC2 = S[:,1] #The second principal component 
    
    coef_cor_PC, pvalue_PC = pearsonr(PC1,PC2)
    print('\ncorrelation coefficient of PC1 and PC2 : \n', coef_cor_PC, pvalue_PC)
    print('\nThere is no linear correlation between the two principal components, PCA transforms the correlated variables of a dataset into a new set of uncorrelated variables')
    
    #PCA model attribute to find the amount of variance explained by each component (PC1 and PC2)
    sum_eig_vals = np.sum(eig_vals)
    explained_variance = eig_vals/ sum_eig_vals
    print('\nExplained Variance for each component : ', explained_variance)
    
    cumulative_variance = np.cumsum(explained_variance)
    print('\nCumulative Variance : ', cumulative_variance)
    
    plt.figure()
    plt.bar(range(4),explained_variance)
    plt.xlabel('Principal Component')
    plt.ylabel('Explained Variance')
    plt.xticks(range(4),['PC1','PC2','PC3','PC4'])
    plt.show()
    
    return S

PCA(x,2)

print('\nConclusion : \n')
print('We could see throught this first part of the TP, the method of principal component analysis which consists in transfoming variables related to each other (called correlated) into new variables are named principal component analysis.')
print('We have verified it by calculating the correlation coefficient between SEPAL LENGTH and SEPAL WIDTH there is a strong correlation between these two samples their correlation coefficient are close.')
print('By Using the PCA method, we have been able to decorrelate these samples, and their correlation coeffcient are not close')



"""-------------------------------Datasets----------------------------------"""
S = PCA(x,2)
principal_df = pd.DataFrame(S , columns = ['PC1','PC2'])
principal_df = pd.concat([principal_df , data.loc[:,['species']]] , axis = 1)
plt.figure()
plt.scatter(principal_df['PC1'], principal_df['PC2'])
sb.scatterplot(data = principal_df , x = 'PC1',y = 'PC2' , hue = 'species' , s = 60 , palette= 'icefire')

"""--------------------------Support Vector Machine-------------------------"""

y = data.loc[:,['species']].values

new_y = np.zeros(144, dtype=int)
for i in range (len(principal_df['species'])):
   if principal_df.loc[i,'species']=='interior':
       new_y[i]=0
   else:
       new_y[i]=1

svm = SVC(kernel="linear", C=1E10)
svm.fit(S, new_y)     

w=svm.coef_[0]
a = -w[0] / w[1]
xx = np.linspace(0, 3)
yy = a* xx - (svm.intercept_[0] / w[1])

marg = 1/np.sqrt(np.sum(svm.coef_**2))
yy_min=yy-np.sqrt(1+a**2)*marg
yy_max=yy+np.sqrt(1+a**2)*marg
plt.figure()
plt.plot(xx,yy,"k--")
plt.plot(xx,yy_min,"k--")
plt.plot(xx,yy_max,"k--")
sb.scatterplot(data = principal_df , x = 'PC1',y = 'PC2' , hue = 'species' , s = 60 , palette= 'icefire')
plt.title('Hyperplane and decision boundaries in the PCA representation')

#Evaluating the model
pred_y = svm.predict(S)
confusion_matrix(new_y,pred_y)

print("Accuracy : ",metrics.accuracy_score(new_y,pred_y))




